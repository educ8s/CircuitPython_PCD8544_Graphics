# CircuitPython_PCD8544_Graphics
 Graphics Libraries for the PCD8544 (Nokia5110) display.
 
 It offers a big numbers font and the following functions:
 
 1. drawFullScreenBitmap(display,image)
 2. draw_number(number, x, y, display)
